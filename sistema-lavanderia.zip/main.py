from roupa import Roupa
from cliente import Cliente
from lavagem import Lavagem
from maquina_lavar import MaquinaLavar
from pagamento import Pagamento
from lavanderia import Lavanderia


def main():
    # Criando a lavanderia
    lavanderia = Lavanderia("Lavanderia Limpeza Total")

    # Criando um cliente
    cliente = Cliente("Maria", "(91) 99999-9999")
    lavanderia.cadastrar_cliente(cliente)

    # Cadastrando roupas
    roupa1 = Roupa("Camiseta", "Branca", "Algodão", 0.3)
    roupa2 = Roupa("Calça", "Azul", "Jeans", 0.8)
    roupa3 = Roupa("Toalha", "Branca", "Algodão", 0.5)

    cliente.adicionar_roupa(roupa1)
    cliente.adicionar_roupa(roupa2)
    cliente.adicionar_roupa(roupa3)

    # Criando uma máquina
    maquina = MaquinaLavar(1, 10)
    lavanderia.adicionar_maquina(maquina)

    # Criando a lavagem
    roupas = cliente.listar_roupas()
    lavagem = Lavagem(cliente, roupas, "normal")
    lavanderia.cadastrar_lavagem(lavagem)

    print("=== SISTEMA DE LAVANDERIA ===")
    print(lavanderia)
    print("\nCliente:")
    print(cliente)

    print("\nRoupas:")
    for roupa in roupas:
        print(roupa)

    print("\nMáquina:")
    print(maquina)

    print("\nIniciando lavagem...")
    print(maquina.iniciar_lavagem())
    lavagem.iniciar()
    print(lavagem)

    print("\nFinalizando lavagem...")
    lavagem.finalizar()
    print(maquina.finalizar_lavagem())
    print(lavagem)

    print("\nRoupas após a lavagem:")
    for roupa in roupas:
        print(roupa)

    # Pagamento
    pagamento = Pagamento(lavagem, "Pix")
    pagamento.realizar_pagamento()

    print("\nPagamento:")
    print(pagamento)


if __name__ == "__main__":
    main()
