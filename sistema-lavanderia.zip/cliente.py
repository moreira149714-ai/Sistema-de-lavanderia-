class Cliente:
    def __init__(self, nome, telefone):
        self.nome = nome
        self.telefone = telefone
        self.roupas = []

    def adicionar_roupa(self, roupa):
        self.roupas.append(roupa)

    def listar_roupas(self):
        return self.roupas

    def __str__(self):
        return f"{self.nome} - Telefone: {self.telefone}"
