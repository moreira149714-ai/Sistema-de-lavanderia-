class Pagamento:
    def __init__(self, lavagem, forma_pagamento):
        self.lavagem = lavagem
        self.forma_pagamento = forma_pagamento
        self.valor = lavagem.valor
        self.status = "Pendente"

    def realizar_pagamento(self):
        self.status = "Pago"

    def __str__(self):
        return (
            f"Pagamento: R$ {self.valor:.2f} | "
            f"Forma: {self.forma_pagamento} | Status: {self.status}"
        )
