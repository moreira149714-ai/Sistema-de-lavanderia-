# Sistema de Lavanderia

Projeto de Programação Orientada a Objetos (POO) em Python.

## Classes

1. Roupa
2. Cliente
3. Lavagem
4. MaquinaLavar
5. Pagamento
6. Lavanderia

## Objetivo

Criar um sistema simples para cadastrar clientes e roupas, realizar lavagens, controlar máquinas e registrar pagamentos.

## Tecnologia

- Python
- Programação Orientada a Objetos (POO)

## Como executar

No terminal, dentro da pasta do projeto:

```bash
python main.py
```
