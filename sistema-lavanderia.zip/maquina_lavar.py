class MaquinaLavar:
    def __init__(self, numero, capacidade):
        self.numero = numero
        self.capacidade = capacidade
        self.ocupada = False

    def iniciar_lavagem(self):
        if self.ocupada:
            return "A máquina já está ocupada."
        self.ocupada = True
        return f"Máquina {self.numero} iniciou a lavagem."

    def finalizar_lavagem(self):
        self.ocupada = False
        return f"Máquina {self.numero} está livre."

    def __str__(self):
        status = "Ocupada" if self.ocupada else "Livre"
        return f"Máquina {self.numero} - Capacidade: {self.capacidade}kg - {status}"
