class Lavagem:
    def __init__(self, cliente, roupas, tipo_lavagem):
        self.cliente = cliente
        self.roupas = roupas
        self.tipo_lavagem = tipo_lavagem
        self.status = "Aguardando"
        self.valor = self.calcular_valor()

    def calcular_valor(self):
        peso_total = sum(roupa.peso for roupa in self.roupas)

        precos = {
            "normal": 8.00,
            "delicada": 12.00,
            "pesada": 15.00
        }

        preco_por_kg = precos.get(self.tipo_lavagem.lower(), 8.00)
        return peso_total * preco_por_kg

    def iniciar(self):
        self.status = "Em lavagem"

    def finalizar(self):
        self.status = "Concluída"
        for roupa in self.roupas:
            roupa.marcar_lavada()

    def __str__(self):
        return (
            f"Lavagem de {self.cliente.nome} | "
            f"Tipo: {self.tipo_lavagem} | "
            f"Valor: R$ {self.valor:.2f} | Status: {self.status}"
        )
