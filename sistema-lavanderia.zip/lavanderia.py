class Lavanderia:
    def __init__(self, nome):
        self.nome = nome
        self.clientes = []
        self.lavagens = []
        self.maquinas = []

    def cadastrar_cliente(self, cliente):
        self.clientes.append(cliente)

    def cadastrar_lavagem(self, lavagem):
        self.lavagens.append(lavagem)

    def adicionar_maquina(self, maquina):
        self.maquinas.append(maquina)

    def listar_clientes(self):
        for cliente in self.clientes:
            print(cliente)

    def listar_lavagens(self):
        for lavagem in self.lavagens:
            print(lavagem)

    def __str__(self):
        return f"{self.nome} - Clientes: {len(self.clientes)} - Lavagens: {len(self.lavagens)}"
