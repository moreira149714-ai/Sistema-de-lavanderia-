class Roupa:
    def __init__(self, tipo, cor, tecido, peso):
        self.tipo = tipo
        self.cor = cor
        self.tecido = tecido
        self.peso = peso
        self.status = "Suja"

    def __str__(self):
        return f"{self.tipo} - {self.cor} - {self.tecido} - {self.peso}kg - {self.status}"

    def marcar_lavada(self):
        self.status = "Lavada"
